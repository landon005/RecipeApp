package com.merchant.user.recipeapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private String jsonRecipeT = Link.primeLink + Link.api + Link.GET_RECIPE_TYPE;
    private String jsonRecipe = Link.primeLink + Link.api + Link.VIEW_RECIPE;
    private static ProgressDialog mProgressDialog;
    private final int jsoncode = 1;
    ArrayList<RecipeType> typeDataArrayList = new ArrayList<>();
    private ArrayList<RecipeModel> recipeModelArrayList;
    ArrayList<String> typeName = new ArrayList<>();
    ArrayList<String> typeClip = new ArrayList<>();
    private RecipeAdapter recipeAdapter;
    RecyclerView rv1;
    Spinner s1;
    Button b1, b2;

    public String recipeName;
    public String recipeType;
    public String rIngredient;
    public String rMethod;
    public String rPic;
    public String rClipArt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        s1 = findViewById(R.id.spinner);
        rv1 = findViewById(R.id.recyclerView);
        b1 = findViewById(R.id.button);
        b2 = findViewById(R.id.button2);

        loadSpinnerData(jsonRecipeT);
        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String jsonRType = typeName.get(i);
                String fullLink = jsonRecipe + "recipe_type=" + jsonRType;
                fetchRecipeJSON(fullLink); /* Showing selected spinner item */
                Log.i("Str" ,jsonRType);
                Toast.makeText(adapterView.getContext(), "Selected: " + jsonRType, Toast.LENGTH_LONG).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentRecipe = new Intent(MainActivity.this, ViewRecipe.class);
                intentRecipe.putExtra("recipe_name", recipeName);
                intentRecipe.putExtra("recipe_type", recipeType);
                intentRecipe.putExtra("recipe_ingredients", rIngredient);
                intentRecipe.putExtra("recipe_method", rMethod);
                intentRecipe.putExtra("recipe_pic", rPic);
                intentRecipe.putExtra("recipe_clipart", rClipArt);
                startActivity(intentRecipe);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentAdd = new Intent(MainActivity.this, AddRecipe.class);
                intentAdd.putExtra("recipeN", "");
                startActivity(intentAdd);
            }
        });

    }

    private void loadSpinnerData(String url) {
        showSimpleProgressDialog(this, "Loading...","Fetching Json",false);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject jsonObject = new JSONObject(response);
                    if(jsonObject.getString("status").equals("1")){
                        JSONArray jsonArray = jsonObject.getJSONArray("data");
                        for(int i = 0; i < jsonArray.length(); i++){
                            RecipeType hModel = new RecipeType();
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            hModel.setType(jsonObject1.getString("recipe_type"));
                            hModel.setTypeClip(jsonObject1.getString("clip_art"));
                            typeDataArrayList.add(hModel);
                        }

                        for (int i = 0; i < typeDataArrayList.size(); i++){
                            typeName.add(typeDataArrayList.get(i).getType());
                            typeClip.add(typeDataArrayList.get(i).getTypeClip());
                        }

                        RecipeTypeAdapter spinnerArrayAdapter = new RecipeTypeAdapter(MainActivity.this, typeClip, typeName, MainActivity.this);
                        //spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        s1.setAdapter(spinnerArrayAdapter);

                        removeSimpleProgressDialog();
                    }
                } catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        requestQueue.add(stringRequest);
    }

    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();

        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showSimpleProgressDialog(Context context, String title, String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }

            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }
        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("StaticFieldLeak")
    private void fetchRecipeJSON(final String url){
        showSimpleProgressDialog(MainActivity.this, "Loading...","Fetching recipes",false);

        new AsyncTask<Void, Void, String>(){
            protected String doInBackground(Void[] params) {
                String response;
                HashMap<String, String> map = new HashMap<>();
                try {
                    HttpRequest req = new HttpRequest(url);
                    response = req.prepare(HttpRequest.Method.POST).withData(map).sendAndReadString();
                } catch (Exception e) {
                    response = e.getMessage();
                }
                return response;
            }

            protected void onPostExecute(String result) {
                // do something with response
                Log.d("List of subject",result);
                onTaskCompleted(result,jsoncode);
            }
        }.execute();
    }

    private void onTaskCompleted(String response, int serviceCode) {
        Log.d("responsejson", response);
        switch (serviceCode) {
            case jsoncode:

                if (isSuccess(response)) {
                    removeSimpleProgressDialog();  // will remove progress dialog
                    recipeModelArrayList = getInfo(response);
                    recipeAdapter = new RecipeAdapter(MainActivity.this, recipeModelArrayList, MainActivity.this);

                    rv1.setAdapter(recipeAdapter);
                    rv1.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false));
                } else {
                    Toast.makeText(MainActivity.this, getErrorCode(response), Toast.LENGTH_SHORT).show();
                }

                break;

            case 2:

                break;

        }
    }

    private ArrayList<RecipeModel> getInfo(String response) {
        ArrayList<RecipeModel> rModelArrayList = new ArrayList<>();
        Log.i("Recipe Data", "Recipe Data - " + response);
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.getString("status").equals("1")) {
                JSONArray dataArray = jsonObject.getJSONArray("data");

                for (int i = 0; i < dataArray.length(); i++) {
                    RecipeModel rModel = new RecipeModel();
                    JSONObject dataobj = dataArray.getJSONObject(i);
                    rModel.setRecipeName(dataobj.getString("recipe_name"));
                    rModel.setType(dataobj.getString("recipe_type"));
                    rModel.setIngredient(dataobj.getString("ingredients"));
                    rModel.setMethod(dataobj.getString("method"));
                    rModel.setPic(dataobj.getString("recipe_pic"));
                    rModelArrayList.add(rModel);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return rModelArrayList;
    }

    private boolean isSuccess(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            if (jsonObject.optString("status").equals("1")) {
                return true;
            } else {
                return false;
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }

    private String getErrorCode(String response) {
        try {
            JSONObject jsonObject = new JSONObject(response);
            return jsonObject.getString("message");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return "No data";
    }



}
