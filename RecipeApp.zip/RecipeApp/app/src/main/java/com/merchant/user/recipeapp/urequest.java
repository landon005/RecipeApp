package com.merchant.user.recipeapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

/**
 * Created by tionchuantung on 24/04/2018.
 */

public class urequest {

    private ProgressDialog pro;
    private dbuilder progress = new dbuilder();






//    /* upload single document (Vehicle Registration and Vehicle Insurance) */
//    @SuppressLint("StaticFieldLeak")
//    public void uploadImage(final Activity activity, final File file, final String fileType) {
//        new AsyncTask<String, String, String>() {
//
//            @Override
//            protected void onPreExecute() {
//                super.onPreExecute();
//
//            }
//
//            @Override
//            protected String doInBackground(String... params) {
//
//                String responseString = "";
//                MediaType MEDIA_TYPE_FORM = MediaType.parse("image/png");
//                MultipartBody.Builder mMultiBuilder = new MultipartBody.Builder();
//
//                try {
//                    mMultiBuilder
//                            .addFormDataPart("user_id", sp.getUsernameId(activity)).setType(MultipartBody.FORM);
//
//                    mMultiBuilder
//                            .addFormDataPart("file_type", fileType).setType(MultipartBody.FORM);
//
//                    mMultiBuilder.addFormDataPart("file", "image.png", RequestBody.create(MEDIA_TYPE_FORM, file))
//                            .addPart(new ImageRequestBody(file, "image/*", new ImageRequestBody.ProgressListener() {
//                                @Override
//                                public void transferred(long num, long size) {
//                                    Long percentage_used = (long) ((float) num / size * 100);
////                                    Log.e("% ", percentage_used + "");
////                                    publishProgress(percentage_used + "");
//                                }
//                            }));
//
//                    RequestBody formBody = mMultiBuilder.build();
//                    okhttp3.Request request = new okhttp3.Request.Builder()
//                            .url(Link.URL_UPLOAD_DOC)
//                            .header("Accept","application/json")
//                            .header("Content-Type","multipart/form-data")
//                            .post(formBody)
//                            .build();
//
//                    OkHttpClient client = new OkHttpClient.Builder()
//                            .connectTimeout(60, TimeUnit.SECONDS)
//                            .readTimeout(60, TimeUnit.SECONDS)
//                            .writeTimeout(60, TimeUnit.SECONDS)
//                            .build();
//                    client.writeTimeoutMillis();
//                    okhttp3.Response response = client.newCall(request).execute();
//                    responseString = response.body().string();
//                    response.body().close();
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                return responseString;
//            }
//
//
//            protected void onProgressUpdate(String... progress) {
//                super.onProgressUpdate(progress);
//
//            }
//
//            @Override
//            protected void onPostExecute(String s) {
//                super.onPostExecute(s);
//
//                try {
//                    Log.i("Check","Check - " + s);
//                    JSONObject jsonObject = new JSONObject(s);
//                    Integer status = jsonObject.getInt("status");
//
//                    if (status == 1) {
//                        Toast.makeText(activity, "File uploaded.", Toast.LENGTH_LONG).show();
//                    } else {
//                        Toast.makeText(activity, "Error Submitting info from server.", Toast.LENGTH_LONG).show();
//                    }
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }.execute();
//    }

    /* upload two-sided document (Driver's IC and Driver's Driving License) */
    @SuppressLint("StaticFieldLeak")
    public void uploadTwoImage(final Activity activity, final File file1, final File file2, final String rName, final String rType, final String rIngred, final String rMethod) {
        new AsyncTask<String, String, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected String doInBackground(String... params) {
                String responseString = "";
                MediaType MEDIA_TYPE_FORM = MediaType.parse("image/png");
                MultipartBody.Builder mMultiBuilder = new MultipartBody.Builder();

                Log.i("R Name", "R Name = " + rName);
                Log.i("R Ingred", "R Ingred = " + rIngred);
                Log.i("R Method", "R Method = " + rMethod);
                Log.i("R Type", "R Type = " + rType);

                try {
                    mMultiBuilder
                            .addFormDataPart("recipe_name", rName).setType(MultipartBody.FORM);

                    mMultiBuilder
                            .addFormDataPart("recipe_type", rType).setType(MultipartBody.FORM);

                    mMultiBuilder
                            .addFormDataPart("ingredients", rIngred).setType(MultipartBody.FORM);

                    mMultiBuilder
                            .addFormDataPart("method", rMethod).setType(MultipartBody.FORM);

                    mMultiBuilder.addFormDataPart("file", "image.png", RequestBody.create(MEDIA_TYPE_FORM, file1))
                            .addPart(new ImageRequestBody(file1, "image/*", new ImageRequestBody.ProgressListener() {
                                @Override
                                public void transferred(long num, long size) {
                                    Long percentage_used = (long) ((float) num / size * 100);
                                    Log.e("% ", percentage_used + "");
//                                    publishProgress(percentage_used + "");
                                }
                            }));

                    mMultiBuilder.addFormDataPart("file2", "image.png", RequestBody.create(MEDIA_TYPE_FORM, file2))
                            .addPart(new ImageRequestBody(file2, "image/*", new ImageRequestBody.ProgressListener() {
                                @Override
                                public void transferred(long num, long size) {
                                    Long percentage_used = (long) ((float) num / size * 100);
                                    Log.e("% ", percentage_used + "");
//                                    publishProgress(percentage_used + "");
                                }
                            }));

                    RequestBody formBody = mMultiBuilder.build();
                    okhttp3.Request request = new okhttp3.Request.Builder()
                            .url(Link.primeLink + Link.api + Link.URL_UPLOAD_TWODOC)
                            .header("Accept","application/json")
                            .header("Content-Type","multipart/form-data")
                            .post(formBody)
                            .build();

                    OkHttpClient client = new OkHttpClient.Builder()
                            .connectTimeout(220, TimeUnit.SECONDS)
                            .readTimeout(220, TimeUnit.SECONDS)
                            .writeTimeout(220, TimeUnit.SECONDS)
                            .build();
                    client.writeTimeoutMillis();
                    okhttp3.Response response = client.newCall(request).execute();
                    responseString = response.body().string();
                    response.body().close();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                return responseString;
            }


            protected void onProgressUpdate(String... progress) {
                super.onProgressUpdate(progress);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    Log.i("Check","Check - " + s);
                    JSONObject jsonObject = new JSONObject(s);
                    Integer status = jsonObject.getInt("status");

                    if (status == 1) {
                        Toast.makeText(activity, "File uploaded.", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(activity, "Error Submitting info from server.", Toast.LENGTH_LONG).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.execute();
    }

    @SuppressLint("StaticFieldLeak")
    public void uploadOneImage(final Activity activity, final String url, final File file1, final String rName, final String rType) {
        new AsyncTask<String, String, String>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected String doInBackground(String... params) {
                String responseString = "";
                MediaType MEDIA_TYPE_FORM = MediaType.parse("image/png");
                MultipartBody.Builder mMultiBuilder = new MultipartBody.Builder();

                Log.i("R Name", "R Name = " + rName);
                //Log.i("R Ingred", "R Ingred = " + rIngred);
                //Log.i("R Method", "R Method = " + rMethod);
                Log.i("R Type", "R Type = " + rType);

                try {
                    mMultiBuilder
                            .addFormDataPart("recipe_name", rName).setType(MultipartBody.FORM);

                    mMultiBuilder
                            .addFormDataPart("recipe_type", rType).setType(MultipartBody.FORM);

                    mMultiBuilder.addFormDataPart("file", "image.png", RequestBody.create(MEDIA_TYPE_FORM, file1))
                            .addPart(new ImageRequestBody(file1, "image/*", new ImageRequestBody.ProgressListener() {
                                @Override
                                public void transferred(long num, long size) {
                                    Long percentage_used = (long) ((float) num / size * 100);
                                    Log.e("% ", percentage_used + "");
//                                    publishProgress(percentage_used + "");
                                }
                            }));

                    RequestBody formBody = mMultiBuilder.build();
                    okhttp3.Request request = new okhttp3.Request.Builder()
                            .url(url)
                            .header("Accept","application/json")
                            .header("Content-Type","multipart/form-data")
                            .post(formBody)
                            .build();

                    OkHttpClient client = new OkHttpClient.Builder()
                            .connectTimeout(220, TimeUnit.SECONDS)
                            .readTimeout(220, TimeUnit.SECONDS)
                            .writeTimeout(220, TimeUnit.SECONDS)
                            .build();
                    client.writeTimeoutMillis();
                    okhttp3.Response response = client.newCall(request).execute();
                    responseString = response.body().string();
                    response.body().close();

                } catch (Exception e) {
                    e.printStackTrace();
                }
                return responseString;
            }


            protected void onProgressUpdate(String... progress) {
                super.onProgressUpdate(progress);

            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    Log.i("Check","Check - " + s);
                    JSONObject jsonObject = new JSONObject(s);
                    Integer status = jsonObject.getInt("status");

                    if (status == 1) {
                        Toast.makeText(activity, "File uploaded.", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(activity, "Error Submitting info from server.", Toast.LENGTH_LONG).show();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.execute();
    }

    public void updtRecipe(final Activity activity, final String rName, final String rType, final String rIngred, final String rMethod) {
        @SuppressLint("StaticFieldLeak")
        class register extends AsyncTask<Void, Void, String> {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                pro = progress.normal(activity, "Registering...");  /* progress dialog - processing the registration of the user */
                pro.setCancelable(false);
                pro.show();
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                pro.dismiss();

                try {
                    Log.i("Check","Check - " + s);
                    JSONObject jo = new JSONObject(s);          /* JSON object declaration*/
                    int status = jo.getInt("status");     /* get the status of the JSON result */

                    if (status == 0) {  /* status = 0 - failed registration of the user */
                        Toast.makeText(activity, "Fail - " + jo.getString("msg"), Toast.LENGTH_LONG).show();
                    } else {    /* otherwise, status = 1 - successful registration of the user */
                        Toast.makeText(activity, "Success - " + jo.getString("msg"), Toast.LENGTH_LONG).show();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... params) {
                HttpHandler httpHandler = new HttpHandler();        /* handling of HTTP requests (HttpHandler.class) */
                HashMap<String, String> data = new HashMap<>();     /* append of the input parameters to the designated URL */
                data.put("recipe_name", rName);
                data.put("recipe_type", rType);
                data.put("ingredients", rIngred);
                data.put("method", rMethod);
                return httpHandler.sendPostRequest(Link.primeLink + Link.api + Link.URL_UPDATE_RECIPE, data);    /* POST the input parameters for registration of the new user */
            }
        }
        new register().execute();
    }


}
