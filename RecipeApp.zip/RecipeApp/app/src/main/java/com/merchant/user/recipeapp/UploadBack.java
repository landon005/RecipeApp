package com.merchant.user.recipeapp;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileNotFoundException;

public class UploadBack extends AppCompatActivity {
    private static final String LOG_TAG = "Text API";
    private static final int PHOTO_REQUEST = 10;
    private Uri imageUri;
    private static final int REQUEST_WRITE_PERMISSION = 20;
    private static final String SAVED_INSTANCE_URI = "uri";

    ImageView backdriverIC;
    Button confirmUTwo;
    String fileTypeStr;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_back);

        actionBarInit();

        //frontdriverIC = findViewById(R.id.front_picX2);
        backdriverIC = findViewById(R.id.back_picX);
        confirmUTwo = findViewById(R.id.upload_front_btn2);

        //frontdriverIC.setImageBitmap(BitmapHelper.getInstance().getBitmap());

        backdriverIC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                takePicture();
            }
        });

        confirmUTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (BitmapHelper.getInstance().getBitmap2() == null) {
                    Toast.makeText(UploadBack.this, "Bitmap cannot be null.", Toast.LENGTH_SHORT).show();
                } else {
                    Intent uLoadB = new Intent(UploadBack.this, AddRecipe.class);
                    startActivity(uLoadB);
                }
            }
        });


    }

    public void actionBarInit(){
        Intent intent = getIntent();
        //fileTypeStr = intent.getStringExtra("filetype");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Recipe Clip Art");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_WRITE_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    takePicture();
                } else {
                    Toast.makeText(UploadBack.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }
                break;

            case 50:

                break;

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PHOTO_REQUEST && resultCode == RESULT_OK) {
            launchMediaScanIntent();
            try {
                Bitmap bitmap = decodeBitmapUri(this, imageUri);
                if (bitmap != null) {
                    backdriverIC.setImageURI(imageUri);
                    BitmapHelper.getInstance().setBitmap2(bitmap);
                    BitmapHelper.getInstance().setBitmapUri2(imageUri);
                    Toast.makeText(this, "Back image loaded!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "Could not set up the viewer!", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Failed to load Image", Toast.LENGTH_SHORT).show();
                Log.e(LOG_TAG, e.toString());
            }
        }
    }
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == this.RESULT_CANCELED) {
//            return;
//        }
//        if (requestCode == CAMERA) {
////            if (!image_view) {
////                if (photoUri2 != null) {
////                    backdriverIC.setImageURI(photoUri2);
////                }
////            }
//            //bitmap2 = null;
//            try {
//                bitmap2 = MediaStore.Images.Media.getBitmap(this.getContentResolver(), photoUri2);
//                saveImage(bitmap2);
//                BitmapHelper.getInstance().setBitmap2(bitmap2);
//                BitmapHelper.getInstance().setBitmapUri2(photoUri2);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//
//
//        }
//
//    }

    File photo;
    private void takePicture() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        photo = new File(Environment.getExternalStorageDirectory(), "picture.jpg");
        imageUri = FileProvider.getUriForFile(UploadBack.this, BuildConfig.APPLICATION_ID + ".provider", photo);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, PHOTO_REQUEST);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (imageUri != null) {
            outState.putString(SAVED_INSTANCE_URI, imageUri.toString());
        }
        super.onSaveInstanceState(outState);
    }

    private void launchMediaScanIntent() {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        mediaScanIntent.setData(imageUri);
        this.sendBroadcast(mediaScanIntent);
    }

    private Bitmap decodeBitmapUri(Context ctx, Uri uri) throws FileNotFoundException {
        int targetW = 600;
        int targetH = 600;
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        int scaleFactor = Math.min(photoW / targetW, photoH / targetH);
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;

        return BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
    }


}
