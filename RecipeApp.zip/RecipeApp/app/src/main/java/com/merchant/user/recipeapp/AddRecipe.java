package com.merchant.user.recipeapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class AddRecipe extends AppCompatActivity {
    Button b3, b4, b6;
    EditText e1, e2, e3, e4;
    ImageView iv3, iv4;
    Bitmap bitmap, bitmap2;
    File frontFile, backFile;
    urequest ur = new urequest();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_recipe);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b6 = findViewById(R.id.button6);
        iv3 = findViewById(R.id.imageView3);
        iv4 = findViewById(R.id.imageView4);
        e1 = findViewById(R.id.editText);
        e2 = findViewById(R.id.editText2);
        e3 = findViewById(R.id.editText3);
        e4 = findViewById(R.id.editText4);

        Intent i = getIntent();
        if (!(i.getStringExtra("recipeN").equals(""))) {
            String recipeName = i.getStringExtra("recipeN");
            String recipeType = i.getStringExtra("recipeT");
            String rIngredient = i.getStringExtra("recipeIng");
            String rMethod = i.getStringExtra("recipeMeth");
            String rPic = i.getStringExtra("recipePic");
            String rClipArt = i.getStringExtra("recipeCA");

            e1.setText(recipeName);
            e2.setText(recipeType);
            e3.setText(rIngredient);
            e4.setText(rMethod);

            Glide.with(this).load(Link.primeLink + rPic).into(iv3);
            Glide.with(this).load(Link.primeLink + rClipArt).into(iv4);

            b4.setVisibility(View.GONE);
            b4.setEnabled(false);
            b3.setVisibility(View.GONE);
            b3.setEnabled(false);
            b6.setVisibility(View.VISIBLE);
            b6.setEnabled(true);

        } else {

            b4.setVisibility(View.VISIBLE);
            b4.setEnabled(true);
            b3.setVisibility(View.VISIBLE);
            b3.setEnabled(false);
            b6.setVisibility(View.GONE);
            b6.setEnabled(false);
        }

        if ((BitmapHelper.getInstance().getBitmap() != null) && (BitmapHelper.getInstance().getBitmap2() != null)) {
            b4.setEnabled(false);
            b3.setEnabled(true);
            iv3.setImageBitmap(BitmapHelper.getInstance().getBitmap());
            try {
                //bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), BitmapHelper.getInstance().getBitmapUri());
                bitmap = decodeBitmapUri(this, BitmapHelper.getInstance().getBitmapUri());
                saveImage(bitmap);
            } catch (IOException e1) {
                e1.printStackTrace();
            }

            iv4.setImageBitmap(BitmapHelper.getInstance().getBitmap2());
            try {
                //bitmap2 = MediaStore.Images.Media.getBitmap(this.getContentResolver(), BitmapHelper.getInstance().getBitmapUri2());
                bitmap2 = decodeBitmapUri2(this, BitmapHelper.getInstance().getBitmapUri2());
                saveImage2(bitmap2);
            } catch (IOException e2) {
                e2.printStackTrace();
            }

        }

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent frontPic = new Intent(AddRecipe.this, UploadFront.class);
                startActivity(frontPic);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String rName = e1.getText().toString();
                String rType = e2.getText().toString();
                String rIngred = e3.getText().toString();
                String rMethod = e4.getText().toString();
                ur.uploadTwoImage(AddRecipe.this, frontFile, backFile, rName, rType, rIngred, rMethod);
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String rName = e1.getText().toString();
                String rType = e2.getText().toString();
                String rIngred = e3.getText().toString();
                String rMethod = e4.getText().toString();
                ur.updtRecipe(AddRecipe.this, rName, rType, rIngred, rMethod);
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private String saveImage(Bitmap myBitmap) {
        Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + "/mtrips/image");
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this, new String[]{f.getPath()}, new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::---&gt;" + f.getAbsolutePath());
            frontFile = f;
            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

    private String saveImage2(Bitmap myBitmap) {
        Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + "/mtrips/image");
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this, new String[]{f.getPath()}, new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::---&gt;" + f.getAbsolutePath());
            backFile = f;
            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

    private Bitmap decodeBitmapUri(Context ctx, Uri uri) throws FileNotFoundException {
        int targetW = 600;
        int targetH = 600;
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        int scaleFactor = Math.min(photoW / targetW, photoH / targetH);
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;

        return BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
    }

    private Bitmap decodeBitmapUri2(Context ctx, Uri uri) throws FileNotFoundException {
        int targetW = 600;
        int targetH = 600;
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        int scaleFactor = Math.min(photoW / targetW, photoH / targetH);
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;

        return BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
    }



}
