package com.merchant.user.recipeapp;

public class Link {

    public static String primeLink = "http://192.168.0.2/scheduler";  /* local web server */
    //public static String primeLink = "http://recipe.appsquest.org";  /* live web server */

    public static String api = "/api/";     /* link to API controller */

    /* API function call */
    public static String GET_RECIPE_TYPE = "get-recipe-type";
    public static String VIEW_RECIPE = "view-recipe?";
    public static String URL_UPLOAD_TWODOC = "upload-pic";
    public static String URL_UPDATE_RECIPE = "update-recipe?";
    public static String URL_REUPLOAD_PIC = "reupload-pic";
    public static String URL_REUPLOAD_CLIP = "reupload-clip";

}
