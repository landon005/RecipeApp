package com.merchant.user.recipeapp;

public class RecipeType {

    private String rType, rTypeClip;

    public String getType() {
        return rType;
    }

    public void setType(String type) {
        this.rType = type;
    }

    public String getTypeClip() {
        return rTypeClip;
    }

    public void setTypeClip(String typeClip) {
        this.rTypeClip = typeClip;
    }


}
