package com.merchant.user.recipeapp;

public class RecipeModel {

    private String recipe_name, type, ingred, metho, pic;

    public void setRecipeName(String name){
        this.recipe_name = name;
    }

    public String getRecipeName(){
        return recipe_name;
    }

    public void setType(String type){
        this.type = type;
    }

    public String getType(){
        return type;
    }

    public void setIngredient(String ingred){
        this.ingred = ingred;
    }

    public String getIngredient(){
        return ingred;
    }

    public void setMethod(String metho){
        this.metho = metho;
    }

    public String getMethod(){
        return metho;
    }

    public void setPic(String pic){
        this.pic = pic;
    }

    public String getPic(){
        return pic;
    }


}
