package com.merchant.user.recipeapp;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.MyViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<RecipeModel> mValues;
    private Context mContext;
    private MainActivity mainActivity;

    public RecipeAdapter(Context context, ArrayList<RecipeModel> values, MainActivity mainActivity) {
        inflater = LayoutInflater.from(context);
        this.mValues = values;
        this.mContext = context;
        this.mainActivity = mainActivity;
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        TextView t8;
        LinearLayout ll6;
        CardView cv1;

        public MyViewHolder(View v) {
            super(v);

            t8 = v.findViewById(R.id.textView8);
            cv1 = v.findViewById(R.id.cardView);
        }

    }

    @NonNull
    @Override
    public RecipeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.recipe_card, parent, false);
        return new RecipeAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecipeAdapter.MyViewHolder Vholder, final int position) {
        final String indRecipe = mValues.get(position).getRecipeName();
        final String indRecipeT = mValues.get(position).getType();
        final String indIngred = mValues.get(position).getIngredient();
        final String indMetho = mValues.get(position).getMethod();
        final String indPic = mValues.get(position).getPic();
        Vholder.t8.setText(indRecipe);

        Vholder.cv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mainActivity.recipeName = mValues.get(position).getRecipeName();
                mainActivity.recipeType = mValues.get(position).getType();
                mainActivity.rIngredient = mValues.get(position).getIngredient();
                mainActivity.rMethod = mValues.get(position).getMethod();
                mainActivity.rPic = mValues.get(position).getPic();
                Toast.makeText(mContext, "Recipe Selected: " + mValues.get(position).getRecipeName(), Toast.LENGTH_SHORT).show();
            }
        });


    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }




}
