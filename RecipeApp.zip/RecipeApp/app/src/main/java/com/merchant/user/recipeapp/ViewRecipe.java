package com.merchant.user.recipeapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class ViewRecipe extends AppCompatActivity {
    ImageView iv1;
    TextView t3, t5, t7;
    Button b5, b7, b8;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_recipe);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        t3 = findViewById(R.id.textView3);
        t5 = findViewById(R.id.textView5);
        t7 = findViewById(R.id.textView7);
        iv1 = findViewById(R.id.imageView);
        b5 = findViewById(R.id.button5);
        b7 = findViewById(R.id.button7);
        b8 = findViewById(R.id.button8);

        Intent intentRecipe = getIntent();
        final String recipeName = intentRecipe.getStringExtra("recipe_name");
        final String recipeType = intentRecipe.getStringExtra("recipe_type");
        final String rIngredient = intentRecipe.getStringExtra("recipe_ingredients");
        final String rMethod = intentRecipe.getStringExtra("recipe_method");
        final String rPic = intentRecipe.getStringExtra("recipe_pic");
        final String rClipArt = intentRecipe.getStringExtra("recipe_clipart");
        String rPicFull = Link.primeLink + rPic.replace(" ", "%20");

        Log.i("JSON 1", "recipe name = " + recipeName);
        Log.i("JSON 2", "recipe type = " + recipeType);
        Log.i("JSON 3", "recipe ingredient = " + rIngredient);
        Log.i("JSON 4", "recipe method = " + rMethod);
        Log.i("JSON 5", "recipe pic = " + rPic);
        Log.i("JSON 6", "recipe clip art = " + rClipArt);

        Glide.with(ViewRecipe.this).load(rPicFull).into(iv1);

        t3.setText(recipeName);
        t5.setText(rIngredient);
        t7.setText(rMethod);

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(ViewRecipe.this, AddRecipe.class);
                i.putExtra("recipeN", recipeName);
                i.putExtra("recipeT", recipeType);
                i.putExtra("recipeIng", rIngredient);
                i.putExtra("recipeMeth", rMethod);
                i.putExtra("recipePic", rPic);
                i.putExtra("recipeCA", rClipArt);
                startActivity(i);
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i2 = new Intent(ViewRecipe.this, UploadSingle.class);
                i2.putExtra("cachedStr", "pic");
                i2.putExtra("recipeN", recipeName);
                i2.putExtra("recipeT", recipeType);
                startActivity(i2);
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i3 = new Intent(ViewRecipe.this, UploadSingle.class);
                i3.putExtra("cachedStr", "clip");
                i3.putExtra("recipeN", recipeName);
                i3.putExtra("recipeT", recipeType);
                startActivity(i3);
            }
        });

    }



}
