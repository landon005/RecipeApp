package com.merchant.user.recipeapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class RecipeTypeAdapter extends ArrayAdapter<String> {
    private ArrayList<String> spinnerClipArt;
    private ArrayList<String> spinnerType;
    private Context mContext;
    private MainActivity mainActivity;

    public RecipeTypeAdapter(@NonNull Context context, ArrayList<String> clipImages, ArrayList<String> clipType, MainActivity mainActivity) {
        super(context, R.layout.recipetypes);
        this.spinnerClipArt = clipImages;
        this.spinnerType = clipType;
        this.mContext = context;
        this.mainActivity = mainActivity;
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return getView(position, convertView, parent);
    }

    @Override
    public int getCount() {
        return spinnerType.size();
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder mViewHolder = new ViewHolder();
        if (convertView == null) {
            LayoutInflater mInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = mInflater.inflate(R.layout.recipetypes, parent, false);
            mViewHolder.iv2 = convertView.findViewById(R.id.imageView2);      /* display the country flag */
            mViewHolder.t9 = convertView.findViewById(R.id.textView9);     /* display the country title code */
            convertView.setTag(mViewHolder);
        } else {
            mViewHolder = (ViewHolder) convertView.getTag();
        }

        mainActivity.rClipArt = spinnerClipArt.get(position);
        String fullClipArt = Link.primeLink + spinnerClipArt.get(position);
        Glide.with(mContext).load(fullClipArt).into(mViewHolder.iv2);
        mViewHolder.t9.setText(spinnerType.get(position));

        return convertView;
    }

    private static class ViewHolder {
        ImageView iv2;
        TextView t9;
    }
}
