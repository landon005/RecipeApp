package com.merchant.user.recipeapp;

import android.graphics.Bitmap;
import android.net.Uri;


public class BitmapHelper {
    private static final BitmapHelper instance = new BitmapHelper();

    private Bitmap singlebitmap = null;
    private Uri singlebitmapUri;

    /* two-sided documents */
    private Bitmap bitmap = null;
    private Bitmap bitmap2 = null;
    private Uri bitmapUri, bitmapUri2;

    /* four-sided photos */
    private Bitmap bitmapA1 = null;
    private Bitmap bitmapA2 = null;
    private Bitmap bitmapA3 = null;
    private Bitmap bitmapA4 = null;
    private Uri bitmapUriA1, bitmapUriA2, bitmapUriA3, bitmapUriA4;

    public BitmapHelper() {

    }

    public static BitmapHelper getInstance() {
        return instance;
    }

//    public Bitmap getSingleBitmap() {
//        return singlebitmap;
//    }
//
//    public void setSingleBitmap(Bitmap singlebitmap) {
//        this.singlebitmap = singlebitmap;
//    }
//
//    public Uri getSingleBitmapUri() {
//        return singlebitmapUri;
//    }
//
//    public void setSingleBitmapUri(Uri singlebitmapUri) {
//        this.singlebitmapUri = singlebitmapUri;
//    }

/* ---------- to upload two-sided documents ---------------------------------------- */

/* ---------- to upload front-side document ---------- */
    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public Uri getBitmapUri() {
        return bitmapUri;
    }

    public void setBitmapUri(Uri bitmapUri) {
        this.bitmapUri = bitmapUri;
    }

/* ---------- to upload back-side document ---------- */
    public Bitmap getBitmap2() {
        return bitmap2;
    }

    public void setBitmap2(Bitmap bitmap2) {
        this.bitmap2 = bitmap2;
    }

    public Uri getBitmapUri2() {
        return bitmapUri2;
    }

    public void setBitmapUri2(Uri bitmapUri2) {
        this.bitmapUri2 = bitmapUri2;
    }

/* ---------- to upload four-sided photos ---------------------------------------- */

/* ---------- to upload photo at angle 1 ---------- */
    public Bitmap getBitmapA1() {
        return bitmapA1;
    }

    public void setBitmapA1(Bitmap bitmapa1) {
        this.bitmapA1 = bitmapa1;
    }

    public Uri getBitmapUriA1() {
        return bitmapUriA1;
    }

    public void setBitmapUriA1(Uri bitmapUria1) {
        this.bitmapUriA1 = bitmapUria1;
    }

/* ---------- to upload photo at angle 2 ---------- */
    public Bitmap getBitmapA2() {
        return bitmapA2;
    }

    public void setBitmapA2(Bitmap bitmapa2) {
        this.bitmapA2 = bitmapa2;
    }

    public Uri getBitmapUriA2() {
        return bitmapUriA2;
    }

    public void setBitmapUriA2(Uri bitmapUria2) {
        this.bitmapUriA2 = bitmapUria2;
    }

/* ---------- to upload photo at angle 3 ---------- */
    public Bitmap getBitmapA3() {
        return bitmapA3;
    }

    public void setBitmapA3(Bitmap bitmapa3) {
        this.bitmapA3 = bitmapa3;
    }

    public Uri getBitmapUriA3() {
        return bitmapUriA3;
    }

    public void setBitmapUriA3(Uri bitmapUria3) {
        this.bitmapUriA3 = bitmapUria3;
    }

/* ---------- to upload photo at angle 4 ---------- */
    public Bitmap getBitmapA4() {
        return bitmapA4;
    }

    public void setBitmapA4(Bitmap bitmapa4) {
        this.bitmapA4 = bitmapa4;
    }

    public Uri getBitmapUriA4() {
        return bitmapUriA4;
    }

    public void setBitmapUriA4(Uri bitmapUria4) {
        this.bitmapUriA4 = bitmapUria4;
    }



}
