package com.merchant.user.recipeapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;

/**
 * Created by tionchuantung on 24/04/2018.
 */

public class dbuilder extends Activity {

    ProgressDialog progDailog;

    public ProgressDialog normal(Context context, String label){

        progDailog = new ProgressDialog(context);
        progDailog.setMessage(label);

        return progDailog;
    }

    public AlertDialog.Builder Dnormal(Context context, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        return builder;
    }

//    public AlertDialog.Builder logout(final Activity activity){
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        String message = "Are you sure you want to logout?";
//        builder.setMessage(message);
//        builder.setPositiveButton("logout", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
////                sPreferences sp = new sPreferences();
//////                sp.removeAPIkey(activity);
//                Intent intent = new Intent(activity, Login.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                activity.startActivity(intent);
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.dismiss();
//            }
//        });
//
//        return builder;
//    }

//    public AlertDialog transfer(final ListActivity activity, String message) {
//        final EditText taskEditText = new EditText(activity);
//        taskEditText.setGravity(Gravity.CENTER);
//        final AlertDialog builder = new AlertDialog.Builder(activity).create();
//        builder.setMessage(message);
//        builder.setView(taskEditText);
//        builder.setButton(AlertDialog.BUTTON_POSITIVE,"Confirm", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                activity.transferON = true;
//                String task = taskEditText.getText().toString();
//
//                if (TextUtils.isEmpty(taskEditText.getText())) {
//                    taskEditText.setError("Enter transfer code");
//                    taskEditText.requestFocus();
//                    Toast.makeText(activity, "Enter valid transfer code", Toast.LENGTH_LONG).show();
//                    return;
//                }
//                trequest trequest = new trequest();
//                trequest.transferTripNo(activity, task);
//            }
//        });
//
//        builder.setButton(AlertDialog.BUTTON_NEGATIVE,"cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                activity.acDialog.setVisibility(View.GONE);
//
//            }
//        });
//
//        builder.show();
//
//        Button btnPositive = builder.getButton(AlertDialog.BUTTON_POSITIVE);
//        Button btnNegative = builder.getButton(AlertDialog.BUTTON_NEGATIVE);
//
//        btnPositive.setBackgroundColor(Color.YELLOW);
//        btnPositive.setTextColor(Color.BLACK);
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//            btnPositive.setElevation(10);
//        }
//        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) btnPositive.getLayoutParams();
//        layoutParams.weight = 10;
//        btnPositive.setLayoutParams(layoutParams);
//        btnNegative.setLayoutParams(layoutParams);
//
//
//        return builder;
//    }
//
//    public AlertDialog.Builder transferTripConf(final RequestCodeActivity activity, String message, final String idc) {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage(message);
//        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                trequest trequest = new trequest();
//                trequest.transferTrip(activity, idc);
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.dismiss();
//            }
//        });
//
//        return builder;
//    }
//
//    public AlertDialog.Builder contactCustomer(final ListActivity activity, final String message, final String idc) {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage(message);
//        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                trequest trequest = new trequest();
//                trequest.contactCustomer(idc,activity);
//
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.dismiss();
//            }
//        });
//
//        return builder;
//    }
//
//    public AlertDialog.Builder acceptTransferTrip(final TransAcceptance activity, String message, final String idc) {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage(message);
//        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.dismiss();
//                trequest trequest = new trequest();
//                trequest.acceptTransfer(activity, idc);
//
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//            }
//        });
//
//        return builder;
//    }
//
//    public AlertDialog.Builder rejectTransferTrip(final TransAcceptance activity, String message, final String idc) {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage(message);
//        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.dismiss();
//                trequest trequest = new trequest();
//                trequest.rejectTransfer(activity, idc);
//
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//            }
//        });
//
//        return builder;
//    }
//
//    public AlertDialog cancelJob(final ListActivity activity, String message, final String idc, final double price, final long hour) {
//
//        String title = "Penalty for cancellation";
//        double amt = 0;
//        String info = "";
//        NumberFormat format = new DecimalFormat("#0.00");
//
//        if (hour > 48) {
//            amt = (price/100.0f) * 0;
//            info = "( More than : 48 hours = 0% penalty )";
//        } else if (hour <= 48 && hour > 36) {
//            amt = (price/100.0f) * 10;
//            info = "( less than : 48 hours = 10% penalty )";
//        } else if (hour <= 36 && hour >= 24) {
//            amt = (price/100.0f) * 50;
//            info = "( less than : 36 hours = 50% penalty )";
//        }
//
//        final AlertDialog builder = new AlertDialog.Builder(activity).create();
//        builder.setMessage(Html.fromHtml(title + "\n<h3> RM " + format.format(amt) + " penalty" + "</h3>\n" + info + "<br><br>" + message));
//        builder.setButton(AlertDialog.BUTTON_POSITIVE,"Yes", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                trequest trequest = new trequest();
//                trequest.cancelOrderJob(activity, idc);
//            }
//        });
//
//        builder.setButton(AlertDialog.BUTTON_NEGATIVE,"No", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//            }
//        });
//
//        builder.show();
//
//        Button btnPositive = builder.getButton(AlertDialog.BUTTON_POSITIVE);
//        Button btnNegative = builder.getButton(AlertDialog.BUTTON_NEGATIVE);
//
//        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) btnPositive.getLayoutParams();
//        layoutParams.weight = 20;
//        btnPositive.setLayoutParams(layoutParams);
//        btnNegative.setLayoutParams(layoutParams);
//
//        return builder;
//    }
//
//    public AlertDialog.Builder acceptJobConf(final ListActivity activity, String message, final String idc){
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setTitle("Notification");
//        builder.setMessage(message);
//        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                activity.acDialog.setVisibility(View.GONE);
//                trequest trequest = new trequest();
//                trequest.acceptJob(activity, idc);
//
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//            }
//        });
//
//        return builder;
//    }
//
//    public AlertDialog.Builder wazeOpen(final Activity activity, final String message){
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage("Open waze to " + message + " ?");
//        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                String uri = "waze://?q="+message;
//                String type = message.replace(" ", "");
//
//                if(type.equalsIgnoreCase("k1")){
//                    uri = "waze://?q=klia 1";
//
//                }else if(type.equalsIgnoreCase("k2")){
//                    uri = "waze://?q=klia 2";
//
//                }else if(type.equalsIgnoreCase("k1/k2")){
//                    uri = "waze://?q=klia 2";
//
//                }
//
//                activity.startActivity(new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(uri)));
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//            }
//        });
//
//        return builder;
//    }
//
//    public AlertDialog.Builder callNumber(final ListActivity activity, final String message){
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage("Select " + message + " for ");
//        final callPerm perm = new callPerm();
//
//        builder.setPositiveButton("Direct call", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                perm.callP(activity, message);
//            }
//        });
//
//        builder.setNegativeButton("Copy", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(CLIPBOARD_SERVICE);
//                ClipData clip = ClipData.newPlainText("Mtrips", message);
//                clipboard.setPrimaryClip(clip);
//                Toast.makeText(activity, "number copied", Toast.LENGTH_LONG).show();
//            }
//        });
//
//        return builder;
//    }
//
//
//    public AlertDialog.Builder acceptJobSuccess(final ListActivity activity, String message){
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage(message);
//        builder.setCancelable(false);
//        builder.setPositiveButton("Proceed to order list", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                activity.switchTab(1);
//
//            }
//        }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//                trequest trequest = new trequest();
//                trequest.getTrips("","","",activity);
////                activity.refresh();
//            }
//        });
//
//        return builder;
//    }
//
//    public AlertDialog.Builder acceptJobDone(final ListActivity activity, String message){
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage(message);
//        builder.setCancelable(false);
//        builder.setPositiveButton("Proceed to history list", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                activity.switchTab(3);
//
//            }
//        }).setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                activity.refresh();
//            }
//        });
//
//        return builder;
//    }
//
//    public void changePass(final Activity activity){
//        View view = LayoutInflater.from(activity).inflate(R.layout.profile_changepass, null);
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setTitle("Change Password");
//        builder.setCancelable(false);
//
//        final EditText Cpass = view.findViewById(R.id.profile_change_curr);
//        final EditText Npass = view.findViewById(R.id.profile_change_newpass);
//        final EditText NCpass = view.findViewById(R.id.profile_change_newpassconf);
//
//        builder.setPositiveButton("Change", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                urequest urequest = new urequest();
//                urequest.changePass(activity, Cpass.getText().toString().trim(),
//                        Npass.getText().toString().trim(), NCpass.getText().toString().trim());
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//
//
//            }
//        });
//
//        builder.setView(view);
//        builder.show();
//
//    }
//
//    public void enterClaimCode(final String id, final String code, final Activity activity){
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setTitle("Notification");
//        View viewInflated = LayoutInflater.from(activity).inflate(R.layout.claim_code, null);
//        final EditText input = (EditText) viewInflated.findViewById(R.id.input);
//        builder.setView(viewInflated);
//
//        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.dismiss();
//                String c_Text = input.getText().toString();
//
//                if (!c_Text.equals(code)){
//                    Toast.makeText(activity, "Invalid Code!", Toast.LENGTH_LONG).show();
//                } else {
//                    trequest trequest = new trequest();
//                    trequest.update_claim(id, (MerchHistoryDetail) activity);
//                }
//
//            }
//        });
//        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.cancel();
//            }
//        });
//
//        builder.show();
//
//    }
//
//    public AlertDialog.Builder cartCheckOut(final MerchCartActivity activity, String message, final String ja) {
//
//        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
//        builder.setMessage(message);
//        builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                trequest trequest = new trequest();
//                trequest.CartCheckOut(activity, ja);
//            }
//        });
//
//        builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                dialog.dismiss();
//            }
//        });
//
//        return builder;
//    }
//
//    public void OpenDialogC(final String trip_id, final ListActivity activity){
//        final Dialog dialog = new Dialog(activity);
//        dialog.setContentView(R.layout.dialog_contacted);
//
//        final CheckBox ch1 = (CheckBox) dialog.findViewById(R.id.check1);
//        final CheckBox ch2 = (CheckBox) dialog.findViewById(R.id.check2);
//        final CheckBox ch3 = (CheckBox) dialog.findViewById(R.id.check3);
//        final CheckBox ch4 = (CheckBox) dialog.findViewById(R.id.check4);
//        final CheckBox ch5 = (CheckBox) dialog.findViewById(R.id.check5);
//        final CheckBox ch6 = (CheckBox) dialog.findViewById(R.id.check6);
//        final CheckBox ch7 = (CheckBox) dialog.findViewById(R.id.check7);
//        final CheckBox ch8 = (CheckBox) dialog.findViewById(R.id.check8);
//        final CheckBox ch9 = (CheckBox) dialog.findViewById(R.id.check9);
//        final CheckBox ch10 = (CheckBox) dialog.findViewById(R.id.check10);
//
//        final Button yes = (Button) dialog.findViewById(R.id.contacted);
//        yes.setEnabled(false);
//        yes.setBackgroundResource(R.color.yellow_);
//
//        ch1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch4.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch5.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch6.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch7.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch8.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch9.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        ch10.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                onCheckClick(ch1.isChecked(),ch2.isChecked(),ch3.isChecked(),ch4.isChecked(),ch5.isChecked(),
//                        ch6.isChecked(),ch7.isChecked(),ch8.isChecked(),ch9.isChecked(),ch10.isChecked(), yes);
//            }
//        });
//
//        yes.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                dialog.dismiss();
//                contactCustomer(activity,"Are you sure have contacted Customer?\n\nIf you fail to do so, RM 5 penalty.\n\n", trip_id).show();
//
//            }
//        });
//
//        dialog.show();
//    }
//
//    public void onCheckClick(boolean ch1, boolean ch2, boolean ch3, boolean ch4, boolean ch5,
//                             boolean ch6, boolean ch7, boolean ch8, boolean ch9, boolean ch10, Button yes) {
//
//        if (ch1 && ch2 && ch3 && ch4 && ch5 && ch6 && ch7 && ch8 && ch9 && ch10) {
//
//            yes.setEnabled(true);
//            yes.setBackgroundResource(R.color.yellow);
//
//        } else {
//            yes.setEnabled(false);
//            yes.setBackgroundResource(R.color.yellow_);
//        }
//
//    }

}
