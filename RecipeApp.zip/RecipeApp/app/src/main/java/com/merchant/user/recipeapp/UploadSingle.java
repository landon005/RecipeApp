package com.merchant.user.recipeapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

public class UploadSingle extends AppCompatActivity {
    private static final String LOG_TAG = "Text API";
    private static final int PHOTO_REQUEST = 10;
    private Uri imageUri;
    private static final int REQUEST_WRITE_PERMISSION = 20;
    private static final String SAVED_INSTANCE_URI = "uri";

    ImageView vInsured;
    Button confirmU;
    urequest ur = new urequest();
    File primeFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_single);

        actionBarInit();

        vInsured = findViewById(R.id.vInsurance);
        confirmU = findViewById(R.id.confirm_btn);

        vInsured.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ActivityCompat.requestPermissions(UploadSingle.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_PERMISSION);
            }
        });

        confirmU.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ur.uploadOneImage(UploadSingle.this, url, primeFile, rName, rType);
            }
        });

    }

    String rName, rType, url;
    public void actionBarInit(){
        Intent intent = getIntent();

        rName = intent.getStringExtra("recipeN");
        rType = intent.getStringExtra("recipeT");

        if (intent.getStringExtra("cachedStr").equals("pic")){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Recipe Pic");
            url = Link.primeLink + Link.api + Link.URL_REUPLOAD_PIC;
        } else if (intent.getStringExtra("cachedStr").equals("clip")) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Recipe Clip Art");
            url = Link.primeLink + Link.api + Link.URL_REUPLOAD_CLIP;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_WRITE_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    takePicture();
                } else {
                    Toast.makeText(UploadSingle.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }
                break;

            case 50:

                break;

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == PHOTO_REQUEST && resultCode == RESULT_OK) {
            launchMediaScanIntent();
            try {
                Bitmap bitmap = decodeBitmapUri(this, imageUri);
                if (bitmap != null) {
                    vInsured.setImageURI(imageUri);
                    saveImage(bitmap);
                } else {
                    Toast.makeText(this, "Could not set up the viewer!", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Failed to load Image", Toast.LENGTH_SHORT).show();
                Log.e(LOG_TAG, e.toString());
            }
        }

    }
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == this.RESULT_CANCELED) {
//            return;
//        }
//        if (requestCode == CAMERA) {
//            if (!image_view) {
//                if (photoUri != null) {
//                    vInsured.setImageURI(photoUri);
//                }
//            }
//
//            try {
//                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), photoUri);
//                //Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, 600, 600, true);
//                //bitmap = decodeBitmapUri(this, photoUri);
//
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            saveImage(bitmap);
//            BitmapHelper.getInstance().setSingleBitmap(bitmap);
//            BitmapHelper.getInstance().setSingleBitmapUri(photoUri);
//        }

//    @Override
//    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == this.RESULT_CANCELED) {
//            return;
//        }
//        if (requestCode == CAMERA) {
//            //launchMediaS
//            // canIntent();
//            try {
//                Bitmap bitmap = decodeBitmapUri(this, photoUri);
//                if (!image_view && photoUri != null) {
//                    vInsured.setImageURI(photoUri);
//                    saveImage(bitmap);
//                }
//            } catch (Exception e) {
//                Toast.makeText(this, "Failed to load Image", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }

    public String saveImage(Bitmap myBitmap) {
        Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + "/mtrips/image");
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this, new String[]{f.getPath()}, new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::---&gt;" + f.getAbsolutePath());
            primeFile = f;
            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

//    public String saveImage2(Bitmap myBitmap) {
//        Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
//        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
//        myBitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
//        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + "/mtrips/image");
//        if (!wallpaperDirectory.exists()) {
//            wallpaperDirectory.mkdirs();
//        }
//
//        try {
//            File f = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".jpg");
//            f.createNewFile();
//            FileOutputStream fo = new FileOutputStream(f);
//            fo.write(bytes.toByteArray());
//            MediaScannerConnection.scanFile(this, new String[]{f.getPath()}, new String[]{"image/jpeg"}, null);
//            fo.close();
//            Log.d("TAG", "File Saved::---&gt;" + f.getAbsolutePath());
//            secFile = f;
//            return f.getAbsolutePath();
//        } catch (IOException e1) {
//            e1.printStackTrace();
//        }
//        return "";
//    }

    File photo;
    private void takePicture() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        photo = new File(Environment.getExternalStorageDirectory(), "picture.jpg");
        imageUri = FileProvider.getUriForFile(UploadSingle.this, BuildConfig.APPLICATION_ID + ".provider", photo);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(intent, PHOTO_REQUEST);
    }

//    private void showCamera() {
//        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        if (intent.resolveActivity(getPackageManager()) != null) {
//            File file = null;
//            try {
//                file = createImageFile();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            photoUri = null;
//            if (file != null) {
//                photoUri = FileProvider.getUriForFile(this, "appquest.mtrips.example.provider", /*(use your app signature + ".provider" ) */ file);
//                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
//
//                startActivityForResult(intent, CAMERA);
//            }
//        }
//    }

//    File file;
//    private void showCamera() {
//        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//        file = new File(Environment.getExternalStorageDirectory(), "picture.jpg");
//        photoUri = FileProvider.getUriForFile(this, "appquest.mtrips.example.provider", file);
//        intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
//        startActivityForResult(intent, CAMERA);
//    }

//    private File createImageFile() throws IOException {
//        // Create an image file name
//        String fileName = fileType;
//        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
//        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
//
//        primeFile = File.createTempFile(fileName + timeStamp, ".jpg", storageDir);
//        return primeFile;
//    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (imageUri != null) {
            outState.putString(SAVED_INSTANCE_URI, imageUri.toString());
        }
        super.onSaveInstanceState(outState);
    }

    private void launchMediaScanIntent() {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        mediaScanIntent.setData(imageUri);
        this.sendBroadcast(mediaScanIntent);
    }

    private Bitmap decodeBitmapUri(Context ctx, Uri uri) throws FileNotFoundException {
        int targetW = 600;
        int targetH = 600;
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
        int photoW = bmOptions.outWidth;
        int photoH = bmOptions.outHeight;

        int scaleFactor = Math.min(photoW / targetW, photoH / targetH);
        bmOptions.inJustDecodeBounds = false;
        bmOptions.inSampleSize = scaleFactor;

        return BitmapFactory.decodeStream(ctx.getContentResolver().openInputStream(uri), null, bmOptions);
    }


}
